import subprocess
import os

def run_python_and_node():
    # Mendapatkan direktori saat ini
    current_directory = os.getcwd()

    # Menjalankan skrip Python (a.pyw)
    python_script = os.path.join(current_directory, "a.pyw")
    subprocess.Popen(["python", python_script])

    # Menjalankan server Node.js (server.js)
    node_script = os.path.join(current_directory, "server.js")
    subprocess.Popen(["node", node_script])

if __name__ == "__main__":
    run_python_and_node()
