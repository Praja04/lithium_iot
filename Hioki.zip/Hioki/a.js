const Service = require('node-windows').Service;

// Buat objek layanan baru
const svc = new Service({
    name: 'ApiHioki', // Nama layanan yang akan ditampilkan di Windows Services
    description: 'Api node.js',
    script: 'C:\Users\INTEL NUC\Documents\Hioki\server.js', // Path ke file JavaScript utama Anda
    nodeOptions: [
        '--harmony',
        '--max_old_space_size=4096'
    ]
});

// Jalankan layanan
svc.on('install', () => {
    svc.start();
});

// Install layanan
svc.install();
