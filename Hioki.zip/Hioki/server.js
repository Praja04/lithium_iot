const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);

const port = 3000; // Ubah sesuai dengan port yang Anda inginkan

app.use(bodyParser.json());

app.post('/api/button', (req, res) => {
    const buttonState = req.body.buttonState;
    console.log('Button state:', buttonState);
    // Di sini Anda bisa menambahkan logika untuk menangani data dari ESP8266
    io.emit('buttonStateChange', buttonState);
    res.send('Data diterima dari ESP8266');
});

http.listen(port, '0.0.0.0', () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});
