*Required libraries
None

*Operation example
C:\SampleProgram\Python 3.7.2\LAN_Sample>python main.py
IP?
192.168.1.1
Port?
3500
Please enter the command (Exit with no input)
*idn?
HIOKI,IM7580A,,V1.22
Please enter the command (Exit with no input)


C:\SampleProgram\Python 3.7.2\LAN_Sample>