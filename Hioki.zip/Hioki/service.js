const Service = require('node-windows').Service;

// Membuat sebuah objek layanan baru
const svc = new Service({
  name: 'API',
  description: 'Deskripsi Layanan Anda',
  script: 'C:\Users\INTEL NUC\Documents\Hioki\server.js' // Gantilah dengan lokasi sebenarnya dari server.js Anda
});

// Memperhatikan perubahan status layanan
svc.on('install', () => {
  svc.start();
});

// Memasang layanan baru dan mulai
svc.install();
