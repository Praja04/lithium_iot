# coding: UTF-8

import socket
import time
import tkinter.messagebox
import requests
BUFSIZE = 4096
import mysql.connector



class Lan:
 
    def __init__(self, timeout, gui=False):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_TCP, socket.TCP_NODELAY, 1)
        self.sock.settimeout(timeout)                                   #Timeout
        self.gui = gui

    #Open port
    def open(self, IP, port):
        ret = False

        try:
            self.sock.connect((IP, port))
            ret = True
        except Exception as e:
            if self.gui == True:
                tkinter.messagebox.showerror("Open Error", e)
            else:
                print("Open error")
                print(e)
        
        return ret

    #Close port
    def close(self):
        ret = False

        try:
            self.sock.close()
            ret = True
        except Exception as e:
            if self.gui == True:
                tkinter.messagebox.showerror("Close Error", e)
            else:
                print("Close error")
                print(e)
        
        return ret

    #Send command
    def sendMsg(self, strMsg):
        ret = False

        try:
            strMsg = strMsg + '\r\n'                #Add a terminator, CR+LF, to transmitted command
            self.sock.send(bytes(strMsg, 'utf-8'))  #Convert to byte type and send
            ret = True
        except Exception as e:
            if self.gui == True:
                tkinter.messagebox.showerror("Send Error", e)
            else:
                print("Send Error")
                print(e)

        return ret
    
    #Receive
    def receiveMsg(self, timeout):

        msgBuf = bytes(range(0))                    #Received Data

        try:
            start = time.time()                     #Record time for timeout
            while True:
                rcv  = self.sock.recv(BUFSIZE)
                rcv = rcv.strip(b"\r")              #Delete CR in received data
                if b"\n" in rcv:                    #End the loop when LF is received
                    rcv = rcv.strip(b"\n")          #Ignore the terminator CR
                    msgBuf = msgBuf + rcv
                    msgBuf = msgBuf.decode('utf-8')
                    break
                else:
                    msgBuf = msgBuf + rcv
                
                #Timeout processing
                if  time.time() - start > timeout:
                    msgBuf = "Timeout Error"
                    break
        except Exception as e:
            if self.gui == True:
                tkinter.messagebox.showerror("Receive Error", e)
            else:
                print("Receive Error")
                print(e)
            msgBuf = "Error"

        return msgBuf
    
    #Transmit and receive commands
    def SendQueryMsg(self, strMsg, timeout):
        ret = Lan.sendMsg(self, strMsg)
        if ret:
            msgBuf_str = Lan.receiveMsg(self, timeout)  #Receive response when command transmission is succeeded
        else:
            msgBuf_str = "Error"

        return msgBuf_str

  

    def save_data_to_database(self, data):
        try:
            # Memisahkan data menjadi dua bagian berdasarkan koma
            data_parts = data.split(",")
            
            # Pastikan data terbagi menjadi dua bagian
            if len(data_parts) == 2:
                # Mendapatkan dua bagian data setelah dipisahkan
                data1 = data_parts[0].strip()
                data2 = data_parts[1].strip()
                
                # Mengonversi data1 menjadi float dan memeriksa apakah lebih besar dari 5
                try:
                    data1_float = float(data1)
                    if data1_float > 5:
                        data1 = "NULL"
                except ValueError:
                    # Jika data1 tidak dapat diubah menjadi float, atur sebagai NULL
                    data1 = "NULL"

                # Mengonversi data2 menjadi float dan memeriksa apakah lebih besar dari 5
                try:
                    data2_float = float(data2)
                    if data2_float > 5:
                        data2 = "NULL"
                except ValueError:
                    # Jika data2 tidak dapat diubah menjadi float, atur sebagai NULL
                    data2 = "NULL"
                
                # Mengambil hanya tiga angka di belakang koma
                try:
                    param1 = float(data1)
                    param2 = float(data2)
                    
                    # Melakukan operasi matematika sesuai kebutuhan
                    param1_result = param1 * 1000
                    param2_result = param2 * 1
                    
                    data1 = "{:.3f}".format(param1_result)
                    data2 = "{:.3f}".format(param2_result)
                except ValueError:
                    data1 = "NULL"
                    data2 = "NULL"

                # Membuat payload JSON sesuai dengan format yang diminta oleh API
                payload = {
                    "param1": data1,
                    "param2": data2,
                    "assy_line": "1"
                }
                
                # URL API untuk melakukan POST request
                api_url = "http://portal4.incoe.astra.co.id:8096/insert_data_assy_lithium"
                
                # Melakukan request POST ke API dengan menggunakan payload JSON
                response = requests.post(api_url, json=payload)
                
                # Memeriksa apakah request berhasil (kode status 200)
                if response.status_code == 200:
                    print("Data berhasil disimpan ke database melalui API")
                    print("Param1:", data1)
                    print("Param2:", data2)
                    return True
                else:
                    print("Gagal menyimpan data ke database. Kode status:", response.status_code)
                    return False
            else:
                print("Data tidak valid")
                return False
        except Exception as e:
            print("Error saving data to database:", e)
            return False


