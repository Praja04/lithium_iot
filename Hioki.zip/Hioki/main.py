# coding: UTF-8

from lan import Lan
import subprocess
import mysql.connector
#Timeout(1sec)
Timeout_default = 1
def start_server():
    try:
        subprocess.Popen(['forever', 'start', 'server.js'], cwd=r'C:\Hioki', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
        print("Server started successfully!")
    except Exception as e:
        print("An error occurred:", e)

def main():
    #Instantiation of the LAN communication class
    lan = Lan(Timeout_default)

    #Connect
    print("IP?")
    IP = input()
    print("Port?")
    port = int(input())
    if not lan.open(IP, port):
        return
    
    #Send and receive commands
    while True:
        print("Please enter the command (Exit with no input)")
        command = input()
        #Exit if no input
        if command == "":
            break
        #If the command contains "?"
        if "?" in command :
            msgBuf = lan.SendQueryMsg(command, Timeout_default)
            print(msgBuf) 
        #Send only
        else:
            lan.sendMsg(command)
        
    lan.close()

if __name__ == '__main__':
  main()
  start_server()
